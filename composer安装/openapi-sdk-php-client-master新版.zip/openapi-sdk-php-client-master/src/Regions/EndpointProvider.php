<?php

namespace AlibabaCloud\Client\Regions;

use AlibabaCloud\Client\Traits\EndpointTrait;

/**
 * Class EndpointProvider
 *
 * @package    AlibabaCloud\Client\Regions
 *
 * @deprecated deprecated since version 2.0, Use AlibabaCloud instead.
 * @codeCoverageIgnore
 */
class EndpointProvider
{
    use EndpointTrait;
}
